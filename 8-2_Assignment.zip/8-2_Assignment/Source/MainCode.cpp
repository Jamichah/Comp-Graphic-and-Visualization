
#include <GLFW/glfw3.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

const float PI = 3.14159265f;
const float DEG2RAD = PI / 180.0f;

const float LEFT_EDGE = -1.0f;
const float RIGHT_EDGE = 1.0f;
const float TOP_EDGE = 1.0f;
const float BOTTOM_EDGE = -1.0f;

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

// Generate a random color component between 0 and 1.
float randomColor()
{
    return static_cast<float>(rand()) / RAND_MAX;
}

// --------------------------------------------------
// BRICK CLASS
// --------------------------------------------------
class Brick
{
public:
    float red, green, blue;
    float x, y;
    float width, height;

    BRICKTYPE brick_type;
    ONOFF onoff;

    int health;
    int maxHealth;

    Brick(BRICKTYPE type, float xx, float yy,
        float ww, float hh, float rr, float gg,
        float bb, int hits = 2)
    {
        brick_type = type;
        x = xx;
        y = yy;
        width = ww;
        height = hh;

        red = rr;
        green = gg;
        blue = bb;

        onoff = ON;

        maxHealth = hits;
        health = hits;
    }

    void takeHit()
    {
        if (onoff == OFF)
            return;

        // Reflective bricks remain in the scene.
        if (brick_type == REFLECTIVE)
        {
            red = 1.0f;
            green = 0.9f;
            blue = 0.2f;
            return;
        }

        health--;

        if (health <= 0)
        {
            onoff = OFF;
        }
        else
        {
            // Change color to show damage.
            red = 1.0f;
            green = 0.25f;
            blue = 0.15f;
        }
    }

    void drawBrick() const
    {
        if (onoff == OFF)
            return;

        float halfWidth = width / 2.0f;
        float halfHeight = height / 2.0f;

        // Main brick body
        glColor3f(red, green, blue);

        glBegin(GL_QUADS);
        glVertex2f(x - halfWidth, y - halfHeight);
        glVertex2f(x + halfWidth, y - halfHeight);
        glVertex2f(x + halfWidth, y + halfHeight);
        glVertex2f(x - halfWidth, y + halfHeight);
        glEnd();

        // Bright upper highlight
        glColor3f(
            min(red + 0.25f, 1.0f),
            min(green + 0.25f, 1.0f),
            min(blue + 0.25f, 1.0f)
        );

        glBegin(GL_QUADS);
        glVertex2f(x - halfWidth, y + halfHeight * 0.45f);
        glVertex2f(x + halfWidth, y + halfHeight * 0.45f);
        glVertex2f(x + halfWidth, y + halfHeight);
        glVertex2f(x - halfWidth, y + halfHeight);
        glEnd();

        // Dark outline
        glColor3f(0.08f, 0.08f, 0.13f);

        glBegin(GL_LINE_LOOP);
        glVertex2f(x - halfWidth, y - halfHeight);
        glVertex2f(x + halfWidth, y - halfHeight);
        glVertex2f(x + halfWidth, y + halfHeight);
        glVertex2f(x - halfWidth, y + halfHeight);
        glEnd();
    }
};

// --------------------------------------------------
// CIRCLE CLASS
// --------------------------------------------------
class Circle
{
public:
    float red, green, blue;
    float radius;
    float x, y;
    float velocityX, velocityY;

    Circle(float xx, float yy, float rad,
        float vx, float vy,
        float r, float g, float b)
    {
        x = xx;
        y = yy;
        radius = rad;

        velocityX = vx;
        velocityY = vy;

        red = r;
        green = g;
        blue = b;
    }

    void changeColor()
    {
        red = 0.25f + randomColor() * 0.75f;
        green = 0.25f + randomColor() * 0.75f;
        blue = 0.25f + randomColor() * 0.75f;
    }

    void MoveOneStep(float deltaTime)
    {
        x += velocityX * deltaTime;
        y += velocityY * deltaTime;

        // Bounce off left and right walls.
        if (x - radius < LEFT_EDGE)
        {
            x = LEFT_EDGE + radius;
            velocityX = fabs(velocityX);
            changeColor();
        }
        else if (x + radius > RIGHT_EDGE)
        {
            x = RIGHT_EDGE - radius;
            velocityX = -fabs(velocityX);
            changeColor();
        }

        // Bounce off top and bottom walls.
        if (y + radius > TOP_EDGE)
        {
            y = TOP_EDGE - radius;
            velocityY = -fabs(velocityY);
            changeColor();
        }
        else if (y - radius < BOTTOM_EDGE)
        {
            y = BOTTOM_EDGE + radius;
            velocityY = fabs(velocityY);
            changeColor();
        }
    }

    void CheckCollision(Brick& brick)
    {
        if (brick.onoff == OFF)
            return;

        float halfWidth = brick.width / 2.0f;
        float halfHeight = brick.height / 2.0f;

        // Find the closest point on the brick.
        float closestX = max(
            brick.x - halfWidth,
            min(x, brick.x + halfWidth)
        );

        float closestY = max(
            brick.y - halfHeight,
            min(y, brick.y + halfHeight)
        );

        float differenceX = x - closestX;
        float differenceY = y - closestY;

        float distanceSquared =
            differenceX * differenceX +
            differenceY * differenceY;

        if (distanceSquared > radius * radius)
            return;

        // Determine which side was struck.
        float overlapX =
            halfWidth + radius - fabs(x - brick.x);

        float overlapY =
            halfHeight + radius - fabs(y - brick.y);

        if (overlapX < overlapY)
        {
            if (x < brick.x)
            {
                x = brick.x - halfWidth - radius;
                velocityX = -fabs(velocityX);
            }
            else
            {
                x = brick.x + halfWidth + radius;
                velocityX = fabs(velocityX);
            }
        }
        else
        {
            if (y < brick.y)
            {
                y = brick.y - halfHeight - radius;
                velocityY = -fabs(velocityY);
            }
            else
            {
                y = brick.y + halfHeight + radius;
                velocityY = fabs(velocityY);
            }
        }

        brick.takeHit();
        changeColor();
    }

    void DrawCircle() const
    {
        glColor3f(red, green, blue);

        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);

        for (int i = 0; i <= 60; i++)
        {
            float angle = i * (2.0f * PI / 60.0f);

            glVertex2f(
                x + cos(angle) * radius,
                y + sin(angle) * radius
            );
        }

        glEnd();

        // Small white highlight
        glColor3f(1.0f, 1.0f, 1.0f);

        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x - radius * 0.25f,
            y + radius * 0.25f);

        for (int i = 0; i <= 30; i++)
        {
            float angle = i * (2.0f * PI / 30.0f);

            glVertex2f(
                x - radius * 0.25f +
                cos(angle) * radius * 0.18f,

                y + radius * 0.25f +
                sin(angle) * radius * 0.18f
            );
        }

        glEnd();
    }
};

// --------------------------------------------------
// GLOBAL GAME OBJECTS
// --------------------------------------------------
vector<Brick> bricks;
vector<Circle> world;

bool spaceWasPressed = false;
bool resetWasPressed = false;

// --------------------------------------------------
// CREATE BRICK LAYOUT
// --------------------------------------------------
void createBricks()
{
    bricks.clear();

    const int rows = 4;
    const int columns = 8;

    const float brickWidth = 0.20f;
    const float brickHeight = 0.12f;
    const float spacingX = 0.23f;
    const float spacingY = 0.16f;

    for (int row = 0; row < rows; row++)
    {
        for (int col = 0; col < columns; col++)
        {
            // Offset alternate rows for a staggered layout.
            float offset =
                (row % 2 == 0) ? 0.0f : 0.08f;

            float x =
                -0.81f + col * spacingX + offset;

            float y =
                0.82f - row * spacingY;

            float r = 0.2f;
            float g = 0.2f;
            float b = 0.2f;

            if (row == 0)
            {
                r = 1.0f;
                g = 0.25f;
                b = 0.35f;
            }
            else if (row == 1)
            {
                r = 1.0f;
                g = 0.65f;
                b = 0.15f;
            }
            else if (row == 2)
            {
                r = 0.25f;
                g = 0.85f;
                b = 0.45f;
            }
            else
            {
                r = 0.25f;
                g = 0.55f;
                b = 1.0f;
            }

            BRICKTYPE type = DESTRUCTABLE;
            int hits = 2;

            // Gold reflective bricks in the top row.
            if (row == 0 && (col == 1 || col == 6))
            {
                type = REFLECTIVE;
                r = 1.0f;
                g = 0.9f;
                b = 0.2f;
            }

            bricks.emplace_back(
                type, x, y,
                brickWidth, brickHeight,
                r, g, b, hits
            );
        }
    }
}

// --------------------------------------------------
// CREATE A MOVING BALL
// --------------------------------------------------
void spawnBall()
{
    if (world.size() >= 12)
        return;

    float angle =
        (35.0f + static_cast<float>(rand() % 110))
        * DEG2RAD;

    float speed = 0.55f;

    float vx = cos(angle) * speed;
    float vy = sin(angle) * speed;

    float startX =
        -0.5f + randomColor() * 1.0f;

    float startY = -0.55f;

    Circle ball(
        startX, startY, 0.045f,
        vx, vy,
        0.3f + randomColor() * 0.7f,
        0.3f + randomColor() * 0.7f,
        0.3f + randomColor() * 0.7f
    );

    world.push_back(ball);
}

// --------------------------------------------------
// CIRCLE-TO-CIRCLE COLLISION
// --------------------------------------------------
void checkCircleCollisions()
{
    for (size_t i = 0; i < world.size(); i++)
    {
        for (size_t j = i + 1; j < world.size(); j++)
        {
            Circle& a = world[i];
            Circle& b = world[j];

            float dx = b.x - a.x;
            float dy = b.y - a.y;

            float distanceSquared = dx * dx + dy * dy;
            float minDistance = a.radius + b.radius;

            if (distanceSquared >= minDistance * minDistance)
                continue;

            float distance = sqrt(distanceSquared);

            // Avoid division by zero.
            if (distance < 0.0001f)
            {
                dx = 1.0f;
                dy = 0.0f;
                distance = 1.0f;
            }

            float nx = dx / distance;
            float ny = dy / distance;

            // Separate overlapping balls.
            float overlap = minDistance - distance;

            a.x -= nx * overlap * 0.5f;
            a.y -= ny * overlap * 0.5f;

            b.x += nx * overlap * 0.5f;
            b.y += ny * overlap * 0.5f;

            // Relative velocity along collision normal.
            float relativeVX = b.velocityX - a.velocityX;
            float relativeVY = b.velocityY - a.velocityY;

            float normalSpeed =
                relativeVX * nx + relativeVY * ny;

            // Apply elastic collision only when approaching.
            if (normalSpeed < 0.0f)
            {
                a.velocityX += normalSpeed * nx;
                a.velocityY += normalSpeed * ny;

                b.velocityX -= normalSpeed * nx;
                b.velocityY -= normalSpeed * ny;

                a.changeColor();
                b.changeColor();
            }
        }
    }
}

// --------------------------------------------------
// RESET ANIMATION
// --------------------------------------------------
void resetAnimation()
{
    world.clear();
    createBricks();

    spawnBall();
    spawnBall();
    spawnBall();
}

// --------------------------------------------------
// KEYBOARD INPUT
// --------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GLFW_TRUE);
    }

    bool spacePressed =
        glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS;

    if (spacePressed && !spaceWasPressed)
    {
        spawnBall();
    }

    spaceWasPressed = spacePressed;

    bool resetPressed =
        glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS;

    if (resetPressed && !resetWasPressed)
    {
        resetAnimation();
    }

    resetWasPressed = resetPressed;
}

// --------------------------------------------------
// MAIN PROGRAM
// --------------------------------------------------
int main(void)
{
    srand(static_cast<unsigned int>(time(NULL)));

    if (!glfwInit())
    {
        cout << "Failed to initialize GLFW." << endl;
        return EXIT_FAILURE;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

    GLFWwindow* window = glfwCreateWindow(
        800, 800,
        "CS 330 - Module 8 Brick Collision Animation",
        NULL, NULL
    );

    if (!window)
    {
        cout << "Failed to create GLFW window." << endl;
        glfwTerminate();
        return EXIT_FAILURE;
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    // Initialize the scene.
    resetAnimation();

    double lastFrame = glfwGetTime();

    while (!glfwWindowShouldClose(window))
    {
        double currentFrame = glfwGetTime();

        float deltaTime =
            static_cast<float>(currentFrame - lastFrame);

        lastFrame = currentFrame;

        // Limit large jumps if the application pauses.
        deltaTime = min(deltaTime, 0.033f);

        processInput(window);

        // Move circles and check brick collisions.
        for (size_t i = 0; i < world.size(); i++)
        {
            world[i].MoveOneStep(deltaTime);

            for (size_t j = 0; j < bricks.size(); j++)
            {
                world[i].CheckCollision(bricks[j]);
            }
        }

        // Check circle-to-circle collisions.
        checkCircleCollisions();

        int width, height;
        glfwGetFramebufferSize(window, &width, &height);

        if (height == 0)
            height = 1;

        glViewport(0, 0, width, height);

        // Black/navy arcade background.
        glClearColor(0.025f, 0.035f, 0.09f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        glOrtho(
            -1.0, 1.0,
            -1.0, 1.0,
            -1.0, 1.0
        );

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        // Draw bricks.
        for (size_t i = 0; i < bricks.size(); i++)
        {
            bricks[i].drawBrick();
        }

        // Draw moving circles.
        for (size_t i = 0; i < world.size(); i++)
        {
            world[i].DrawCircle();
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();

    return EXIT_SUCCESS;
}
