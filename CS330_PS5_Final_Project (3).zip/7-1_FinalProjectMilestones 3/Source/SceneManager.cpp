///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>
#include <string>
#include <vector>

namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
}

// Constructor
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0;
}

// Destructor
SceneManager::~SceneManager()
{
    DestroyGLTextures();
    delete m_basicMeshes;
    m_basicMeshes = nullptr;
    m_pShaderManager = nullptr;
}

// Load texture image
bool SceneManager::CreateGLTexture(
    const char* filename, std::string tag)
{
    if (m_loadedTextures >= 16)
        return false;

    int width = 0;
    int height = 0;
    int channels = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(
        filename, &width, &height, &channels, 0);

    if (!image)
    {
        std::cout << "Could not load: "
            << filename << std::endl;
        return false;
    }

    if (channels != 3 && channels != 4)
    {
        stbi_image_free(image);
        return false;
    }

    GLuint textureID = 0;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameteri(GL_TEXTURE_2D,
        GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,
        GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,
        GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,
        GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    GLenum format = channels == 4 ? GL_RGBA : GL_RGB;

    glTexImage2D(GL_TEXTURE_2D, 0,
        format, width, height, 0,
        format, GL_UNSIGNED_BYTE, image);

    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    std::cout << "Loaded texture: "
        << filename << std::endl;

    return true;
}

// Bind textures to available texture units
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

// Release texture resources
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }

    m_loadedTextures = 0;
}

// Find texture ID
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return m_textureIDs[i].ID;
    }

    return -1;
}

// Find texture slot
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag == tag)
            return i;
    }

    return -1;
}

// Find material by tag
bool SceneManager::FindMaterial(
    std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& item : m_objectMaterials)
    {
        if (item.tag == tag)
        {
            material = item;
            return true;
        }
    }

    return false;
}

// Apply model transformations
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);

    glm::mat4 rotationX = glm::rotate(
        glm::radians(XrotationDegrees),
        glm::vec3(1.0f, 0.0f, 0.0f));

    glm::mat4 rotationY = glm::rotate(
        glm::radians(YrotationDegrees),
        glm::vec3(0.0f, 1.0f, 0.0f));

    glm::mat4 rotationZ = glm::rotate(
        glm::radians(ZrotationDegrees),
        glm::vec3(0.0f, 0.0f, 1.0f));

    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 model =
        translation * rotationX * rotationY *
        rotationZ * scale;

    m_pShaderManager->setMat4Value(g_ModelName, model);
}

// Set shader color
void SceneManager::SetShaderColor(
    float red, float green, float blue, float alpha)
{
    m_pShaderManager->setIntValue(
        g_UseTextureName, false);

    m_pShaderManager->setVec4Value(
        g_ColorValueName,
        glm::vec4(red, green, blue, alpha));
}

// Apply texture
void SceneManager::SetShaderTexture(std::string tag)
{
    int slot = FindTextureSlot(tag);

    if (slot >= 0)
    {
        m_pShaderManager->setIntValue(
            g_UseTextureName, true);

        m_pShaderManager->setSampler2DValue(
            g_TextureValueName, slot);
    }
    else
    {
        m_pShaderManager->setIntValue(
            g_UseTextureName, false);
    }
}

// Set texture UV scale
void SceneManager::SetTextureUVScale(float u, float v)
{
    m_pShaderManager->setVec2Value(
        "UVscale", glm::vec2(u, v));
}

// Apply material properties
void SceneManager::SetShaderMaterial(std::string tag)
{
    OBJECT_MATERIAL material;

    if (FindMaterial(tag, material))
    {
        m_pShaderManager->setVec3Value(
            "material.ambientColor",
            material.ambientColor);

        m_pShaderManager->setFloatValue(
            "material.ambientStrength",
            material.ambientStrength);

        m_pShaderManager->setVec3Value(
            "material.diffuseColor",
            material.diffuseColor);

        m_pShaderManager->setVec3Value(
            "material.specularColor",
            material.specularColor);

        m_pShaderManager->setFloatValue(
            "material.shininess",
            material.shininess);
    }
}

///////////////////////////////////////////////////////////////////////////////
// LoadSceneTextures
///////////////////////////////////////////////////////////////////////////////
void SceneManager::LoadSceneTextures()
{
    // Wooden desk texture
    CreateGLTexture(
        "Source/Textures/wood.jpg", "wood");

    // PlayStation monitor image
    CreateGLTexture(
        "Source/Textures/screen.jpg", "screen");

    // WallPaper
    CreateGLTexture(
        "Source/Textures/wallpaper.jpg", "wallpaper");

    BindGLTextures();
}

///////////////////////////////////////////////////////////////////////////////
// SetupSceneLights
// Warm primary light and cool blue secondary light
///////////////////////////////////////////////////////////////////////////////
void SceneManager::SetupSceneLights()
{
    m_pShaderManager->setIntValue("bUseLighting", true);

    // Primary warm light
    m_pShaderManager->setVec3Value(
        "lightSources[0].position",
        glm::vec3(-3.0f, 6.0f, 4.0f));

    m_pShaderManager->setVec3Value(
        "lightSources[0].ambientColor",
        glm::vec3(0.42f, 0.38f, 0.34f));

    m_pShaderManager->setVec3Value(
        "lightSources[0].diffuseColor",
        glm::vec3(1.0f, 0.82f, 0.65f));

    m_pShaderManager->setVec3Value(
        "lightSources[0].specularColor",
        glm::vec3(1.0f, 0.9f, 0.8f));

    m_pShaderManager->setFloatValue(
        "lightSources[0].focalStrength", 32.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[0].specularIntensity", 0.5f);

    // Secondary blue light
    m_pShaderManager->setVec3Value(
        "lightSources[1].position",
        glm::vec3(3.5f, 4.0f, -1.5f));

    m_pShaderManager->setVec3Value(
        "lightSources[1].ambientColor",
        glm::vec3(0.06f, 0.09f, 0.18f));

    m_pShaderManager->setVec3Value(
        "lightSources[1].diffuseColor",
        glm::vec3(0.20f, 0.40f, 0.85f));

    m_pShaderManager->setVec3Value(
        "lightSources[1].specularColor",
        glm::vec3(0.30f, 0.50f, 1.0f));

    m_pShaderManager->setFloatValue(
        "lightSources[1].focalStrength", 32.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[1].specularIntensity", 0.35f);

    // Disable unused lights
    for (int i = 2; i < 4; i++)
    {
        std::string prefix =
            "lightSources[" + std::to_string(i) + "].";

        m_pShaderManager->setVec3Value(
            prefix + "ambientColor", glm::vec3(0.0f));

        m_pShaderManager->setVec3Value(
            prefix + "diffuseColor", glm::vec3(0.0f));

        m_pShaderManager->setVec3Value(
            prefix + "specularColor", glm::vec3(0.0f));
    }
}

///////////////////////////////////////////////////////////////////////////////
// DefineObjectMaterials
///////////////////////////////////////////////////////////////////////////////
void SceneManager::DefineObjectMaterials()
{
    m_objectMaterials.clear();

    OBJECT_MATERIAL wood;
    wood.tag = "woodMaterial";
    wood.ambientStrength = 0.45f;
    wood.ambientColor = glm::vec3(1.0f);
    wood.diffuseColor = glm::vec3(0.85f);
    wood.specularColor = glm::vec3(0.25f);
    wood.shininess = 0.35f;
    m_objectMaterials.push_back(wood);

    OBJECT_MATERIAL white;
    white.tag = "whitePlastic";
    white.ambientStrength = 0.45f;
    white.ambientColor = glm::vec3(1.0f);
    white.diffuseColor = glm::vec3(1.0f);
    white.specularColor = glm::vec3(0.65f);
    white.shininess = 0.55f;
    m_objectMaterials.push_back(white);

    OBJECT_MATERIAL black;
    black.tag = "blackPlastic";
    black.ambientStrength = 0.55f;
    black.ambientColor = glm::vec3(1.0f);
    black.diffuseColor = glm::vec3(0.8f);
    black.specularColor = glm::vec3(0.45f);
    black.shininess = 0.45f;
    m_objectMaterials.push_back(black);
}

///////////////////////////////////////////////////////////////////////////////
// PrepareScene
///////////////////////////////////////////////////////////////////////////////
void SceneManager::PrepareScene()
{
    LoadSceneTextures();

    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadTorusMesh();
    m_basicMeshes->LoadConeMesh();

    DefineObjectMaterials();
    SetupSceneLights();
}

///////////////////////////////////////////////////////////////////////////////
// RenderScene
///////////////////////////////////////////////////////////////////////////////
void SceneManager::RenderScene()
{
    // Helper function to draw boxes
    auto drawBox = [&](glm::vec3 size, glm::vec3 pos,
        glm::vec4 color, const char* material,
        float rx = 0.0f, float ry = 0.0f,
        float rz = 0.0f)
        {
            SetTransformations(size, rx, ry, rz, pos);
            SetShaderColor(color.r, color.g, color.b, color.a);
            SetShaderMaterial(material);
            m_basicMeshes->DrawBoxMesh();
        };

    // Helper function to draw cylinders
    auto drawCylinder = [&](glm::vec3 size, glm::vec3 pos,
        glm::vec4 color, const char* material,
        float rx = 0.0f, float ry = 0.0f,
        float rz = 0.0f)
        {
            SetTransformations(size, rx, ry, rz, pos);
            SetShaderColor(color.r, color.g, color.b, color.a);
            SetShaderMaterial(material);
            m_basicMeshes->DrawCylinderMesh();
        };

    // Helper function to draw spheres
    auto drawSphere = [&](glm::vec3 size, glm::vec3 pos,
        glm::vec4 color, const char* material)
        {
            SetTransformations(size, 0, 0, 0, pos);
            SetShaderColor(color.r, color.g, color.b, color.a);
            SetShaderMaterial(material);
            m_basicMeshes->DrawSphereMesh();
        };

    const glm::vec4 white(0.92f, 0.93f, 0.96f, 1.0f);
    const glm::vec4 black(0.035f, 0.045f, 0.07f, 1.0f);
    const glm::vec4 gray(0.22f, 0.24f, 0.28f, 1.0f);
    const glm::vec4 blue(0.07f, 0.36f, 0.82f, 1.0f);
    const glm::vec4 wallColor(0.53f, 0.43f, 0.35f, 1.0f);


    //////////////////////////////////////////////////////
    // ROOM FLOOR UNDERNEATH GAMING DESK
    //////////////////////////////////////////////////////

    // Large floor beneath the table legs
    SetTransformations(
        glm::vec3(20.0f, 1.0f, 14.0f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, -2.20f, 0.0f));

    // Use the existing wood texture
    SetTextureUVScale(4.0f, 4.0f);
    SetShaderTexture("wood");
    SetShaderMaterial("woodMaterial");

    m_basicMeshes->DrawPlaneMesh();

    // Reset texture scale
    SetTextureUVScale(1.0f, 1.0f);

    ///////////////////////////////////////////////////////////////////////
    // OBJECT 1: WOODEN DESK
    ///////////////////////////////////////////////////////////////////////

    SetTransformations(
        glm::vec3(9.5f, 0.28f, 5.5f),
        0.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 0.10f, 0.0f));

    SetTextureUVScale(2.0f, 1.5f);
    SetShaderTexture("wood");
    SetShaderMaterial("woodMaterial");

    m_basicMeshes->DrawBoxMesh();

    SetTextureUVScale(1.0f, 1.0f);

    // Four wooden table legs
    for (float x : {-4.2f, 4.2f})
    {
        for (float z : {-2.25f, 2.25f})
        {
            drawBox(
                glm::vec3(0.38f, 2.32f, 0.38f),
                glm::vec3(x, -1.04f, z),
                glm::vec4(0.16f, 0.11f, 0.08f, 1.0f),
                "woodMaterial");
        }
    }

    // Front support beam
    drawBox(
        glm::vec3(8.4f, 0.22f, 0.20f),
        glm::vec3(0.0f, -0.35f, 2.25f),
        glm::vec4(0.18f, 0.12f, 0.08f, 1.0f),
        "woodMaterial");

    // Back support beam
    drawBox(
        glm::vec3(8.4f, 0.22f, 0.20f),
        glm::vec3(0.0f, -0.35f, -2.25f),
        glm::vec4(0.18f, 0.12f, 0.08f, 1.0f),
        "woodMaterial");

    // Side support beams
    for (float x : {-4.2f, 4.2f})
    {
        drawBox(
            glm::vec3(0.20f, 0.22f, 4.5f),
            glm::vec3(x, -0.35f, 0.0f),
            glm::vec4(0.18f, 0.12f, 0.08f, 1.0f),
            "woodMaterial");
    }

    //////////////////////////////////////////////////////
    // FULL WALL GAMING WALLPAPER
    //////////////////////////////////////////////////////

    SetTransformations(
        glm::vec3(16.0f, 1.0f, 8.0f),
        90.0f, 0.0f, 0.0f,
        glm::vec3(0.0f, 3.8f, -4.0f));

    SetTextureUVScale(1.0f, 1.0f);
    SetShaderTexture("wallpaper");
    SetShaderMaterial("whitePlastic");

    // Display wallpaper without dark lighting
    m_pShaderManager->setIntValue("bUseLighting", false);

    m_basicMeshes->DrawPlaneMesh();

    // Restore lighting
    m_pShaderManager->setIntValue("bUseLighting", true);


    ///////////////////////////////////////////////////////////////////////
    // OBJECT 3: PLAYSTATION 5 CONSOLE
    // Shifted 0.8 units left to fit fully on the gaming table
    ///////////////////////////////////////////////////////////////////////

    // PS5 circular base
    drawCylinder(
        glm::vec3(1.15f, 0.10f, 0.75f),
        glm::vec3(3.30f, 0.38f, -0.7f),
        black, "blackPlastic");

    // Main black center
    drawBox(
        glm::vec3(0.86f, 3.05f, 0.60f),
        glm::vec3(3.30f, 1.96f, -0.7f),
        black, "blackPlastic");

    // Left white panel
    drawBox(
        glm::vec3(0.19f, 3.25f, 0.78f),
        glm::vec3(2.73f, 2.04f, -0.7f),
        white, "whitePlastic",
        0, 0, -4.0f);

    // Right white panel
    drawBox(
        glm::vec3(0.19f, 3.25f, 0.78f),
        glm::vec3(3.87f, 2.04f, -0.7f),
        white, "whitePlastic",
        0, 0, 4.0f);

    // Blue accent strip
    drawBox(
        glm::vec3(0.045f, 2.60f, 0.035f),
        glm::vec3(2.88f, 2.10f, -0.31f),
        blue, "whitePlastic");

    // Disc slot on front
    drawBox(
        glm::vec3(0.035f, 0.90f, 0.025f),
        glm::vec3(3.70f, 1.10f, -0.30f),
        black, "blackPlastic");

    // Power button
    drawCylinder(
        glm::vec3(0.045f, 0.015f, 0.045f),
        glm::vec3(3.28f, 0.56f, -0.29f),
        blue, "whitePlastic",
        90.0f, 0.0f, 0.0f);


    ///////////////////////////////////////////////////////////////////////
    // OBJECT 4: GAMING MONITOR
    ///////////////////////////////////////////////////////////////////////

    // Monitor frame
    drawBox(
        glm::vec3(5.35f, 3.12f, 0.18f),
        glm::vec3(-1.75f, 3.12f, -1.85f),
        black, "blackPlastic");

    // PlayStation screen image
    SetTransformations(
        glm::vec3(5.02f, 2.78f, 0.025f),
        0, 0, 0,
        glm::vec3(-1.75f, 3.13f, -1.74f));

    SetTextureUVScale(1.0f, 1.0f);
    SetShaderTexture("screen");
    SetShaderMaterial("whitePlastic");

    // Disable lighting for an illuminated display
    m_pShaderManager->setIntValue("bUseLighting", false);
    m_basicMeshes->DrawBoxMesh();
    m_pShaderManager->setIntValue("bUseLighting", true);

    // Monitor stand
    drawBox(
        glm::vec3(0.22f, 1.38f, 0.24f),
        glm::vec3(-1.75f, 0.94f, -1.90f),
        gray, "blackPlastic");

    // Monitor base
    drawBox(
        glm::vec3(1.85f, 0.11f, 1.08f),
        glm::vec3(-1.75f, 0.36f, -1.90f),
        black, "blackPlastic");

    ///////////////////////////////////////////////////////////////////////
    // OBJECT 5: GAMING KEYBOARD
    ///////////////////////////////////////////////////////////////////////

    // Keyboard base
    drawBox(
        glm::vec3(3.25f, 0.13f, 1.03f),
        glm::vec3(-2.35f, 0.41f, 1.02f),
        black, "blackPlastic");

    // Keyboard keys
    for (int row = 0; row < 4; row++)
    {
        for (int col = 0; col < 12; col++)
        {
            float x = -3.79f + col * 0.26f;
            float z = 0.67f + row * 0.23f;

            drawBox(
                glm::vec3(0.20f, 0.065f, 0.17f),
                glm::vec3(x, 0.51f, z),
                row == 0 ? blue : gray,
                "blackPlastic");
        }
    }

    ///////////////////////////////////////////////////////////////////////
    // OBJECT 6: GAMING MOUSE
    ///////////////////////////////////////////////////////////////////////

    // Mouse body
    drawSphere(
        glm::vec3(0.35f, 0.12f, 0.50f),
        glm::vec3(0.45f, 0.45f, 1.10f),
        black, "blackPlastic");

    // Scroll wheel
    drawBox(
        glm::vec3(0.055f, 0.035f, 0.17f),
        glm::vec3(0.45f, 0.565f, 0.97f),
        gray, "blackPlastic");

    ///////////////////////////////////////////////////////////////////////
    // OBJECT 7: TWO PLAYSTATION DUALSENSE CONTROLLERS
    ///////////////////////////////////////////////////////////////////////

    auto drawController = [&](glm::vec3 origin, float factor)
        {
            auto at = [&](float x, float y, float z)
                {
                    return origin + glm::vec3(
                        x * factor,
                        y * factor,
                        z * factor);
                };

            // Main controller body

        // Rounded main controller body
            drawSphere(
                glm::vec3(
                    0.79f * factor,
                    0.17f * factor,
                    0.34f * factor),
                at(0.0f, 0.0f, 0.0f),
                white, "whitePlastic");


            // Black center section

        // Black center panel
            drawBox(
                glm::vec3(
                    0.67f * factor,
                    0.12f * factor,
                    0.35f * factor),
                at(0.0f, 0.08f, 0.02f),
                black, "blackPlastic");



            //////////////////////////////////////////////////////
            // NATURAL DUALSENSE CONTROLLER GRIPS
            // Rounded and angled grips with smooth transitions
            //////////////////////////////////////////////////////

            // Left grip - elongated rounded handle
            SetTransformations(
                glm::vec3(
                    0.29f * factor,
                    0.19f * factor,
                    0.53f * factor),
                0.0f, -22.0f, -8.0f,
                at(-0.57f, -0.06f, 0.25f));

            SetShaderColor(0.92f, 0.93f, 0.96f, 1.0f);
            SetShaderMaterial("whitePlastic");
            m_basicMeshes->DrawSphereMesh();

            // Right grip - elongated rounded handle
            SetTransformations(
                glm::vec3(
                    0.29f * factor,
                    0.19f * factor,
                    0.53f * factor),
                0.0f, 22.0f, 8.0f,
                at(0.57f, -0.06f, 0.25f));

            SetShaderColor(0.92f, 0.93f, 0.96f, 1.0f);
            SetShaderMaterial("whitePlastic");
            m_basicMeshes->DrawSphereMesh();

            // Left shoulder transition
            drawSphere(
                glm::vec3(
                    0.34f * factor,
                    0.17f * factor,
                    0.27f * factor),
                at(-0.48f, 0.0f, 0.03f),
                white, "whitePlastic");

            // Right shoulder transition
            drawSphere(
                glm::vec3(
                    0.34f * factor,
                    0.17f * factor,
                    0.27f * factor),
                at(0.48f, 0.0f, 0.03f),
                white, "whitePlastic");


            drawBox(
                glm::vec3(0.32f * factor,
                    0.22f * factor,
                    0.52f * factor),
                at(0.57f, -0.08f, 0.31f),
                white, "whitePlastic",
                0, 16.0f, 0);

            // Touchpad
            drawBox(
                glm::vec3(0.48f * factor,
                    0.035f * factor,
                    0.30f * factor),
                at(0, 0.15f, -0.07f),
                gray, "blackPlastic");

            // Analog sticks
            for (float x : {-0.26f, 0.26f})
            {
                drawCylinder(
                    glm::vec3(0.12f * factor,
                        0.055f * factor,
                        0.12f * factor),
                    at(x, 0.19f, 0.21f),
                    black, "blackPlastic");
            }

            // Directional pad
            drawBox(
                glm::vec3(0.22f * factor,
                    0.025f * factor,
                    0.065f * factor),
                at(-0.48f, 0.14f, -0.08f),
                black, "blackPlastic");

            drawBox(
                glm::vec3(0.065f * factor,
                    0.025f * factor,
                    0.22f * factor),
                at(-0.48f, 0.14f, -0.08f),
                black, "blackPlastic");

            // Four action buttons
            for (int i = 0; i < 4; i++)
            {
                float bx = 0.47f +
                    (i == 0 ? -0.12f :
                        i == 1 ? 0.12f : 0.0f);

                float bz = -0.07f +
                    (i == 2 ? -0.12f :
                        i == 3 ? 0.12f : 0.0f);

                drawCylinder(
                    glm::vec3(0.045f * factor,
                        0.024f * factor,
                        0.045f * factor),
                    at(bx, 0.15f, bz),
                    blue, "blackPlastic");
            }

            // Blue accent along controller center
            drawBox(
                glm::vec3(0.54f * factor,
                    0.018f * factor,
                    0.025f * factor),
                at(0, 0.145f, -0.25f),
                blue, "whitePlastic");
        };

    // Controller stand
    drawBox(
        glm::vec3(0.12f, 0.67f, 0.18f),
        glm::vec3(1.90f, 0.65f, 0.35f),
        black, "blackPlastic");

    // Upper controller
    drawController(
        glm::vec3(1.90f, 1.06f, 0.35f),
        0.88f);

    // Front controller
    drawController(
        glm::vec3(1.90f, 0.57f, 1.40f),
        1.0f);
}